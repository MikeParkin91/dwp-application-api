package uk.parkin.mike.dwpapplicationapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DwpApplicationApiApplication {

	public static void main(String... args) {
		SpringApplication.run(DwpApplicationApiApplication.class, args);
	}

}
