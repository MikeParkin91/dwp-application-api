package uk.parkin.mike.dwpapplicationapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DwpApplicationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
